"use strict";
(() => {
  // src/config.ts
  var CFG = {
    module: "wfrp4e-pc-trades",
    socket: {
      value: "module.wfrp4e-pc-trades",
      TradeWindowTemplate: "modules/wfrp4e-pc-trades/templates/trade-window.html"
    },
    SETTINGS: {}
  };

  // src/utility.ts
  function getOnlinePlayers(excludedId) {
    let results = new Array();
    if (game.users !== void 0) {
      game.users.forEach((u) => {
        let char = u.character;
        if (u.active && char && char.id !== excludedId) {
          results.push({
            "userId": u.id,
            "name": char.name,
            "img": char.img,
            "id": char.id
          });
        }
      });
    }
    return results;
  }

  // src/trade.ts
  async function openItemTrade(actorId, itemId) {
    try {
      const item = game.actors.get(actorId).items.get(itemId);
      const characters = getOnlinePlayers(actorId);
      if (characters.length === 0) {
        ui.notifications.warn(game.i18n.localize("LetsTrade5E.NoPCToTradeWith"));
      } else {
      }
    } catch {
      console.error("Was unable to complete trade for item: ", itemId);
    }
  }

  // src/items.ts
  async function itemDefault(item, actorId) {
    const edit = $(".item-control.item-edit", item);
    const icon = $(`<a class="item-control item-trade" title="${game.i18n.localize("PCTrades.send")}">
        <i class="fas fa-balance-scale-right"></i></a>`)[0];
    icon.dataset.itemId = item.dataset.itemId;
    icon.dataset.actorId = actorId;
    icon.addEventListener("click", async (event) => {
      await onItemTradeClick(event);
    });
    if (edit[0]) {
      edit[0].after(icon);
    }
  }
  async function onItemTradeClick(event) {
    event.preventDefault();
    if (event.currentTarget instanceof Element) {
      const ele = event.currentTarget.closest(".item-trade");
      const actorId = ele.dataset.actorId;
      const itemId = ele.dataset.itemId;
      await openItemTrade(actorId, itemId);
    }
  }

  // src/main.ts
  Hooks.once("setup", async function() {
    Hooks.on("renderActorSheetWfrp4eCharacter", renderInjectionHook);
    game.socket.on(CFG.socket.value, (packet) => {
      let data = packet.data;
      let type = packet.type;
      let handler = packet.handler;
    });
    console.log("WFRP4E PC Trades Loaded");
  });
  async function renderInjectionHook(sheet, element) {
    const actorId = sheet.actor.id;
    let items = $(".tab.inventory .item", element);
    for (let item of items) {
      try {
        await itemDefault(item, actorId);
      } catch (e) {
        console.error("WFRP4e PC Trades | Failed to inject onto item: ", item);
      }
      console.log("WFRP4e PC Trades | Added trade icons to sheet for actor " + actorId);
    }
  }
})();
